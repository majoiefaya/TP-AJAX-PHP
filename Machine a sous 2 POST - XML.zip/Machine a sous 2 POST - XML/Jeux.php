<?php
include('Preloader.php');
?>
<head>
 
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
<script src="Jeux.js"></script>
<script src="fonctionAjax.js"></script>
<script src="Actualiser.js"></script>
<link rel="stylesheet" href="Style.css">
</head>

<div class="d-flex justify-content-center">
    <img id="charge" src="loading5.gif" />
    <div>
        <form method="POST">
            Votre Portfeuille est de <span id="portfeuille">25000</span>
            <input type="text" name="mise" id="mise" class="form-control"/>
            <select name="niveau" id="niveau" class="custom-select form-control">
                <option value="Facile">Facile</option>
                <option value="Moyen">Moyen</option>     
                <option value="Difficile">Difficile</option>
            </select>
          
            
    <div class="Police" id="info">
        Mr <span><?php echo $_POST["nom"]?></span> 
        <span id="gain"></span>
        <span hidden id="resultat"></span>
    </div>
    <input name="button" type="button" onclick="jouer();" value="JOUER" id="button" class="button"/>
        </form>
    </div>
</div>

    
