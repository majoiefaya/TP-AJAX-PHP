<?php
header("Content-Type: text/plain");
sleep(2);
$parametres=file_get_contents('php://input');

$TabXml=simplexml_load_string($parametres);

$mise=$TabXml->mise;
$portfeuille=$TabXml->portfeuille;
$mise=(int)$mise;
$portfeuille=(int)$portfeuille;

if(isset($TabXml->niveau)) 
$niveau=$TabXml->niveau;
else $niveau="Vous n avez selectionner aucun Niveau";

$gain=rand(0,100);

if($portfeuille>$mise){
    if($gain<50){
        $portfeuille=$portfeuille-$mise;
        $resultat="Vous avez perdu ".$mise.':'.$portfeuille;
        echo $resultat;
    }
    else if($gain>=50 and $gain<75){
        $somme=$mise/2;
        $portfeuille=$portfeuille+$somme;
        $resultat="Vous avez gagné ".$somme.':'.$portfeuille;
        echo $resultat;
    }
    else if($gain>=75 and $gain<100){
        $somme=$mise;
        $portfeuille=$portfeuille+$somme;
        $resultat="Vous avez Fait une double Mise et gagné".$somme.':'.$portfeuille;
        echo $resultat;
    }
}
else if($portfeuille<$mise){
    $portfeuille;
    $resultat="Votre Solde est Insufisant,Il ne vous reste que".':'.$portfeuille;
    echo $resultat;
    
    
}



?>