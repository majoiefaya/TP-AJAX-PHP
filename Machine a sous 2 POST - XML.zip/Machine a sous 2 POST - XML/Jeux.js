
function jouer(){
   
    objetXHR = creationObjetXMLHttpRequest();
    var temps=new Date().getTime();
    var portfeuille=document.getElementById("portfeuille").textContent;
    var mise=document.getElementById("mise").value;
    var niveau=document.getElementById("niveau").value;
  
    var parametres=
    "<parametres>"+
        "<portfeuille>"+portfeuille+"</portfeuille>"+
        "<mise>"+mise+"</mise>"+
        "<niveau>"+niveau+"</niveau>"+
    "</parametres>";
    console.log(parametres);
  
    objetXHR.open("post","gainAleatoireFacile.php",true);
  
    objetXHR.setRequestHeader("Content-Type","text/xml");
    objetXHR.onreadystatechange=actualiserPage;
   
    document.getElementById("button").disabled=true;
    document.getElementById("charge").style.visibility="visible";

    objetXHR.send(parametres);

}

function codeContenu(id){
    var contenu=document.getElementById(id).value;
    return encodeURIComponent(contenu);
}