Menu avec roulette------------------
Url     : http://codes-sources.commentcamarche.net/source/49607-menu-avec-rouletteAuteur  : jdmcreatorDate    : 05/08/2013
Licence :
=========

Ce document intitul� � Menu avec roulette � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

C'est un menu qui utilise une roulette pour se d&eacute;placer. C'est un projet 
que j'ai trouv&eacute; dans mes dossiers il y a quelques temps. Pour meilleurs r
&eacute;sultats, utiliser Safari ou Firefox, car IE ne g&egrave;re pas encore la
 propri&eacute;t&eacute; CSS border-radius.
<br /><a name='source-exemple'></a>
<h2> Source / Exemple : </h2>
<br /><pre class='code' data-mode='basic'>
--&g
t; Dans le ZIP &lt;--
</pre>
<br /><a name='conclusion'></a><h2> Conclusion : 
</h2>
<br />Je crois qu'il y a un moyen de comprimer encore plus ma source ave
c des tableaux et des boucles mais je ne m'y suis pas encore arr&ecirc;t&eacute;
. J'ai encore quelques petits probl&egrave;mes &agrave; r&egrave;gler (transform
er les champs cach&eacute; en variable, transformer le div en image...)
