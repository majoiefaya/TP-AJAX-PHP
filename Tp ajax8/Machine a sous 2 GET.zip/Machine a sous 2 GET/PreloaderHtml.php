<?php
    include('css.php');
?>
    <div id="preloader-active">
        <div class="preloader d-flex align-items-center justify-content-center">
            <div class="preloader-inner position-relative">
                <div class="preloader-circle"></div>
                <div class="preloader-img pere-text">
                    <img src="m.gif" alt="">
                </div>
            </div>
        </div>
    </div>
<?php
    include('script.php');
?>