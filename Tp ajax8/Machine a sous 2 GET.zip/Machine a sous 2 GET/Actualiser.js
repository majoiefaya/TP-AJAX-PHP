function actualiserPage(){
    
    if(objetXHR.readyState==4){
        if(objetXHR.status==200){
            var nouveauGain=objetXHR.responseText;

            document.getElementById("resultat").innerHTML=nouveauGain;

            var tab = nouveauGain.split(':');
            gain=document.getElementById('gain').innerHTML = decodeURI(tab[0]);
            portfeuille=document.getElementById('portfeuille').innerHTML = decodeURI(tab[1]);

            document.getElementById("info").style.visibility="visible";
        
            document.getElementById("button").disabled=false;
            document.getElementById("charge").style.visibility="hidden";
        
        }else{
            document.getElementById("info").innerHTML="Erreur serveur:"+objetXHR.status+" - "+objetXHR.statusText;
            document.getElementById("info").style.visibility="visible";
     
            document.getElementById("button").disabled=false;
            document.getElementById("charge").style.visibility="hidden";

            objetXHR.abort();
            objetXHR=null;
        }
    }
}