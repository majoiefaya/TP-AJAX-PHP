<!DOCTYPE html>
<html lang="en">

<head>
    <title>Mega Able bootstrap admin template by codedthemes </title>
    <!-- HTML5 Shim and Respond.js IE10 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 10]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <!-- Meta -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="description" content="Mega Able Bootstrap admin template made using Bootstrap 4 and it has huge amount of ready made feature, UI components, pages which completely fulfills any dashboard needs." />
    <meta name="keywords" content="flat ui, admin Admin , Responsive, Landing, Bootstrap, App, Template, Mobile, iOS, Android, apple, creative app">
    <meta name="author" content="codedthemes" />
    <!-- Favicon icon -->
   <?php 
    include ('Components/css.php');
   ?>
</head>

<body>
<!-- Pre-loader start -->
<?php 
    include ('Components/Preloader.php');
   ?>
<!-- Pre-loader end -->
<div id="pcoded" class="pcoded">
    <div class="pcoded-overlay-box"></div>
    <div class="pcoded-container navbar-wrapper">
        <div class="pcoded-inner-content">
            <div class="main-body">
                <div class="page-wrapper">
                    <div class="page-body">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h5>Bienvenu</h5>
                                        <span>Casino</span>
                                        <div class="card-header-right">
                                            <ul class="list-unstyled card-option">
                                                <li><i class="fa fa-chevron-left"></i></li>
                                                <li><i class="fa fa-window-maximize full-card"></i></li>
                                                <li><i class="fa fa-minus minimize-card"></i></li>
                                                <li><i class="fa fa-refresh reload-card"></i></li>
                                                <li><i class="fa fa-times close-card"></i></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="card-block">
                                        <p>
                                            Bienvenu Dans Notre Casino 
                                            Voici Les Regles Du jeux:
                                            Niveau Facile:
                                            Vous gagnez Votre mise quand vous etes dans une marge de 75 a 100
                                            Vous gagnez la moitié de la mise de 50 a 75
                                            vous perdez votre Mise en dessous de 50

                                        </p>
                                    </div>
                                </div>
                            </div>
                            <a href="inscription.php" class="btn waves-effect waves-light btn-primary btn-skew">jouer</a>
                        </div>
                    </div>
                </div>
            </div>
            </div>
            </div>
            <div id="styleSelector">  
            </div>
            </div>
        </div>
    </div>
</div>


<?php 
    include ('Components/Scripts.php');
   ?>

</body>

</html>
