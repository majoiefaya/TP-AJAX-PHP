<?php
header("Content-Type: text/plain ; charset=utf-8");
header("Cache-Control:no-cache,private");
header("Pragma:no-cache");
sleep(2);
$parametres=file_get_contents('php://input');

$TabJson=json_decode($parametres);

$mise=$TabJson->mise;
$portfeuille=$TabJson->portfeuille;
$mise=$mise;
$portfeuille=$portfeuille;

if(isset($TabJson->niveau)) 
$niveau=$TabJson->niveau;
else $niveau="Vous n avez selectionner aucun Niveau";
if($portfeuille>$mise){
    if($niveau=="Facile"){
        $gain=rand(0,100);
    
        if($portfeuille>$mise){
            if($gain<50){
                $portfeuille=$portfeuille-$mise;
                $resultat="Vous avez perdu ".$mise.':'.$portfeuille;
                echo $resultat;
            }
            else if($gain>=50 and $gain<75){
                $somme=$mise/2;
                $portfeuille=$portfeuille+$somme;
                $resultat="Vous avez gagné ".$somme.':'.$portfeuille;
                echo $resultat;
            }
            else if($gain>=75 and $gain<100){
                $somme=$mise;
                $portfeuille=$portfeuille+$somme;
                $resultat="Vous avez Fait une double Mise et gagné".$somme.':'.$portfeuille;
                echo $resultat;
            }
        }
    
    }else if($niveau="Moyen"){
        $gain=rand(0,500);

        if($portfeuille>$mise){
            if($gain<250){
                $portfeuille=$portfeuille-$mise;
                $resultat="Vous avez perdu ".$mise.':'.$portfeuille;
                echo $resultat;
            }
            else if($gain>=250 and $gain<375){
                $somme=$mise/2;
                $portfeuille=$portfeuille+$somme;
                $resultat="Vous avez gagné ".$somme.':'.$portfeuille;
                echo $resultat;
            }
            else if($gain>=375 and $gain<500){
                $somme=$mise;
                $portfeuille=$portfeuille+$somme;
                $resultat="Vous avez Fait une double Mise et gagné".$somme.':'.$portfeuille;
                echo $resultat;
            }
        }
    }else if($niveau="Difficile"){
        $gain=rand(0,1000);

        if($portfeuille>$mise){
            if($gain<500){
                $portfeuille=$portfeuille-$mise;
                $resultat="Vous avez perdu ".$mise.':'.$portfeuille;
                echo $resultat;
            }
            else if($gain>=500 and $gain<750){
                $somme=$mise/2;
                $portfeuille=$portfeuille+$somme;
                $resultat="Vous avez gagné ".$somme.':'.$portfeuille;
                echo $resultat;
            }
            else if($gain>=750 and $gain<1000){
                $somme=$mise;
                $portfeuille=$portfeuille+$somme;
                $resultat="Vous avez Fait une double Mise et gagné".$somme.':'.$portfeuille;
                echo $resultat;
            }
        }
    }
}

else{
    $portfeuille;
    $resultat="Votre Solde est Insufisant,Il ne vous reste que".':'.$portfeuille;
    echo $resultat;
    
    
}



?>