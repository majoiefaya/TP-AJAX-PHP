
function jouer(){
   
    objetXHR = creationObjetXMLHttpRequest();
    var temps=new Date().getTime();
    var portfeuille=document.getElementById("portfeuille").textContent;
    var mise=document.getElementById("mise").value;
    var niveau=document.getElementById("niveau").value;
    objetJSon=new Object();
    objetJSon.portfeuille=portfeuille;
    objetJSon.mise=mise;
    objetJSon.niveau=niveau;
    
    var parametres=JSON.stringify(objetJSon);

        objetXHR.open("post","gainAleatoire.php",true);
   

    objetXHR.onreadystatechange=actualiserPage;
    objetXHR.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
    document.getElementById("button").disabled=true;
    document.getElementById("charge").style.visibility="visible";

    objetXHR.send(parametres);

}