<?php
header("Content-Type: text/plain");
sleep(2);
$mise=$_REQUEST['mise'];
$portfeuille=$_REQUEST['portfeuille'];

if(isset($_REQUEST['niveau'])) 
$niveau=$_REQUEST['niveau'];
else $niveau="Vous n avez selectionner aucun Niveau";

$gain=rand(0,1000);

if($portfeuille>$mise){
    if($gain<500){
        $portfeuille=$portfeuille-$mise;
        $resultat="Vous avez perdu ".$mise.':'.$portfeuille;
        echo $resultat;
    }
    else if($gain>=500 and $gain<750){
        $somme=$mise/2;
        $portfeuille=$portfeuille+$somme;
        $resultat="Vous avez gagné ".$somme.':'.$portfeuille;
        echo $resultat;
    }
    else if($gain>=750 and $gain<1000){
        $somme=$mise;
        $portfeuille=$portfeuille+$somme;
        $resultat="Vous avez Fait une double Mise et gagné".$somme.':'.$portfeuille;
        echo $resultat;
    }
}
else if($portfeuille<$mise){
    $portfeuille;
    $resultat="Votre Solde est Insufisant,Il ne vous reste que".':'.$portfeuille;
    echo $resultat;
    
    
}



?>