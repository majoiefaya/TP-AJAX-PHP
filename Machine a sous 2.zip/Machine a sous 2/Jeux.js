
function jouer(){
   
    objetXHR = creationObjetXMLHttpRequest();
    var temps=new Date().getTime();
    var portfeuille=document.getElementById("portfeuille").textContent;
    var mise=document.getElementById("mise").value;
    var niveau=document.getElementById("niveau").value;
  
    var parametres="portfeuille="+portfeuille+"&mise="+mise+"&anticache="+temps;
    if(niveau=="Facile"){
        objetXHR.open("get","gainAleatoireFacile.php?"+parametres,true);
    }else if(niveau=="Moyen"){
        objetXHR.open("get","gainAleatoireMoyen.php?"+parametres,true);
    }else if(niveau=="Difficile"){
        objetXHR.open("get","gainAleatoireDifficile.php?"+parametres,true);
    }
   

    objetXHR.onreadystatechange=actualiserPage;

    document.getElementById("button").disabled=true;
    document.getElementById("charge").style.visibility="visible";

    objetXHR.send(null);

}