<script type="text/javascript" src="js/jquery/jquery.min.js"></script>     <script type="text/javascript" src="js/jquery-ui/jquery-ui.min.js "></script>     <script type="text/javascript" src="js/popper.js/popper.min.js"></script>     <script type="text/javascript" src="js/bootstrap/js/bootstrap.min.js "></script>
<!-- waves js -->
<script src="pages/waves/js/waves.min.js"></script>
<!-- jquery slimscroll js -->
<script type="text/javascript" src="js/jquery-slimscroll/jquery.slimscroll.js "></script>
<!-- modernizr js -->
    <script type="text/javascript" src="js/SmoothScroll.js"></script>     <script src="js/jquery.mCustomScrollbar.concat.min.js "></script>
<script src="js/pcoded.min.js"></script>
<script src="js/vertical-layout.min.js "></script>
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<!-- Custom js -->
<script type="text/javascript" src="js/script.js"></script>