

function actualiserPage(){
    
    if(objetXHR.readyState==4){
        if(objetXHR.status==200){
            var nouveauGain=objetXHR.responseText;

            document.getElementById("resultat").innerHTML=nouveauGain;

            var tab = nouveauGain.split(':');
            gain=document.getElementById('gain').innerHTML = decodeURI(tab[0]);
            portfeuille=document.getElementById('portfeuille').innerHTML = decodeURI(tab[1]);

            document.getElementById("info").style.visibility="visible";
        
            document.getElementById("button").disabled=false;
            document.getElementById("charge").style.visibility="hidden";
        
        }else{
            document.getElementById("info").innerHTML="Erreur serveur:"+objetXHR.status+" - "+objetXHR.statusText;
            document.getElementById("info").style.visibility="visible";

            document.getElementById("button").disabled=false;
            document.getElementById("charge").style.visibility="hidden";

            objetXHR.abort();
            objetXHR=null;
        }
    }
}

function creationObjetXMLHttpRequest(){
    var resultat=null;
    try{
        resultat=new XMLHttpRequest();
    }
    catch(Error){
        try{
            resultat=new ActiveXObject("Msxml2.XMLHTTP");
        }catch(Error){
            try{
                resultat=new ActiveXObject("Microsoft.XMLHTTP");
            }catch(Error){
                resultat=null;
            }
        }
    }
    return resultat;
}

function jouer(){
   
    objetXHR = creationObjetXMLHttpRequest();
    var temps=new Date().getTime();
    var portfeuille=document.getElementById("portfeuille").textContent;
    var mise=document.getElementById("mise").value;
    var niveau=document.getElementById("niveau").value;
    portfeuille=portfeuille-mise;
    var parametres="portfeuille="+portfeuille+"&mise="+mise+"&anticache="+temps;
    if(niveau=="Facile"){
        objetXHR.open("get","gainAleatoireFacile.php?"+parametres,true);
    }else if(niveau=="Moyen"){
        objetXHR.open("get","gainAleatoireMoyen.php?"+parametres,true);
    }else if(niveau=="Difficile"){
        objetXHR.open("get","gainAleatoireDifficile.php?"+parametres,true);
    }
   

    objetXHR.onreadystatechange=actualiserPage;

    document.getElementById("button").disabled=true;
    document.getElementById("charge").style.visibility="visible";

    objetXHR.send(null);

}

function testerNavigateur(){
    objetXHR=creationXHR();
    if(objetXHR==null){
        document.getElementById("button").disabled=true;
        var erreurNavigateur="Erreur Navigateur:Création d'objet XHR impossible";
        remplacerContenu("info",erreurNavigateur);
        document.getElementById("info").style.visibility="visible";
    }
}